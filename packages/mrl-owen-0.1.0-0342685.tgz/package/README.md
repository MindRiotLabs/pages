# MRL / OWEN

> **Organizational Wisdom and Epistemic Network (OWEN)**  
> *Turning organizational reality into experience, experience into wisdom, and wisdom into better human decisions — while preserving individual perspectives and explicit human authority.*

---

## 1. Core Thesis

OWEN sits **one layer above** individual AI models, specialist agents, tools, applications, and commercial vendors.

In modern software organizations, AI agents increasingly propose and execute changes across code, infrastructure, data, and configuration. Without an epistemic supervision layer, teams risk hallucinations, unverified claims, silent drift of architectural policy, and creeping loss of human control.

OWEN provides this supervision layer:
- **Models, agents, tools, vendors, and applications are replaceable capabilities beneath OWEN.**
- **Human authority is a non-negotiable architectural invariant.**

### What AI May and May Not Do

| Permitted Machine Operations | Forbidden Machine Operations |
| :--- | :--- |
| **Observe** repository and system states | **Silently redefine** organizational truth or policy |
| **Analyze** code, architectures, and logs | **Expand** delegated authority boundaries |
| **Test** and run verification suites | **Authorize** its own scope expansion |
| **Recommend** improvements and fixes | **Bypass** human approval on consequential actions |
| **Challenge** unverified specialist claims | **Merge** autonomously to production during calibration |
| **Synthesize** context across repositories | **Flatten** legitimate multi-vendor disagreement |
| **Route & Coordinate** specialist agents | **Enforce** unvalidated beliefs across projects |

---

## 2. Capability Domains

OWEN's organizational intelligence is organized into distinct first-class capabilities:

### OWEN Assurance
Evidence-driven software and system assurance. Supervises specialist agents (e.g. Google Jules, Linters, CI runners) across pull requests, repositories, and live environments without collapsing findings into synthetic scores.

### OWEN Foundry
Venture, product, GTM development, and organizational learning. Transforms unstructured human conversations, field notes, customer discovery interviews, and market signals into falsifiable hypotheses, empirical experiments, and sovereign human decisions.

**Core Invariants in Foundry**:
- **Chat is not the system of record**: Verbatim sources are preserved immutably (`FoundrySource`).
- **Preservation of Perspective**: Individual collaborator viewpoints (`FoundryPerspective`) remain distinct and attributable; no synthetic collapsing into a bland "team opinion."
- **Human Authority**: Only verified human actors can execute decisions (`FoundryDecision`); machines are restricted to synthesizing evidence, detecting contradictions, and framing choices.
- **Evidence Snapshots**: Decisions freeze the exact state of evidence present when rendered.
- **Vertical Scoping**: Insights remain scoped to their vertical (e.g., `hvac`, `service-platform`) and do not pollute universal platform knowledge without explicit promotion.

---

## 3. Human Authority Model

OWEN implements a machine-readable, tri-zone authority model:

```
  ┌──────────────────────────────────────────────────────────────┐
  │                           RED ZONE                           │
  │              Explicit Human Authority Required               │
  │   Policy, Architecture, Destruction, Credentials, Authority  │
  └──────────────────────────────┬───────────────────────────────┘
                                 │
                                 ▼ Escalation
  ┌──────────────────────────────────────────────────────────────┐
  │                         YELLOW ZONE                          │
  │    Investigate Autonomously -> Human Approval Before Action   │
  │   Schema changes, Auth, Billing, Infrastructure, Workflows    │
  └──────────────────────────────┬───────────────────────────────┘
                                 │
                                 ▼ Delegation
  ┌──────────────────────────────────────────────────────────────┐
  │                          GREEN ZONE                          │
  │                  Delegated Machine Discretion                │
  │       Linting, Docs, Dead Code, Tests, Non-breaking fixes    │
  │    *NOTE: Auto-merge is STRICTLY PROHIBITED in calibration*  │
  └──────────────────────────────────────────────────────────────┘
```

- **GREEN (Delegated Machine Discretion)**: Low-risk tasks (doc fixes, linting, tests). In the initial calibration phase, **automatic merge is prohibited**.
- **YELLOW (Autonomous Investigation, Human Approval Required)**: High-impact changes (database schema, authentication, billing, permissions, infrastructure). Machines may investigate and propose PRs; humans must approve before execution.
- **RED (Explicit Human Authority Required)**: Foundational decisions (product goals, compliance posture, privacy rules, destructive data operations, changes to OWEN's own governance or authority). Machine actors cannot self-authorize RED actions.

---

## 4. Role Continuity & The Experience Network

Individual agent instances are ephemeral. Role wisdom should persist independently of any specific model, provider, or agent run.

OWEN defines **Role Continuity**:
- A local node (such as `Assurance:HypeDope`) operates within its own local repository reality.
- Future nodes (such as `Assurance:Mudbowl`) maintain separate local realities while sharing the **Assurance role lineage**.
- Shared role wisdom is communicated through canonical **Experience Events** representing **validated deltas of experience**, not a centralized, unvetted global memory blob.
- **Propagation Scope**: Defaults strictly to `project_only`. Broader distribution (`role_wide`, `organization_wide`, `domain_wide`) requires explicit classification.
- Receipt of an experience event **never** makes it automatically true in another environment.

---

## 5. Repository Layout

```text
MRL-OWEN/
  ├── README.md                           # This document
  ├── AGENTS.md                           # Governing operational invariants for all agents
  ├── package.json                        # Kernel package specification & test scripts
  ├── tsconfig.json                       # TypeScript compiler configuration
  │
  ├── docs/
  │   ├── architecture/                   # Architectural treatises
  │   │   ├── core-principles.md          # OWEN philosophy & thesis
  │   │   ├── assurance.md                # OWEN Assurance operational model
  │   │   ├── OWEN_FOUNDRY_ARCHITECTURE_V0_1.md # OWEN Foundry architecture
  │   │   ├── authority-model.md          # Tri-zone machine-readable governance
  │   │   ├── role-continuity.md          # Ephemeral instances & role lineages
  │   │   └── experience-network.md       # Validated experience events & propagation
  │   └── adr/                            # Architecture Decision Records
  │       ├── 0001-kernel-technology-stack.md
  │       ├── 0002-human-authority-model.md
  │       ├── 0003-epistemic-discipline.md
  │       ├── 0004-role-continuity-and-events.md
  │       ├── 0005-jules-specialist-integration.md
  │       ├── 0007-human-authority-as-stewardship.md
  │       ├── 0008-github-app-live-bridge.md
  │       └── 0009-owen-foundry-architectural-foundation.md
  │
  ├── schemas/                            # Canonical JSON Schemas (Draft 2020-12 / Draft-07)
  │   ├── authority-charter.schema.json   # Machine-readable governance charter
  │   ├── specialist-report.schema.json   # Structured specialist findings
  │   ├── assurance-assessment.schema.json# OWEN Assurance evaluations
  │   ├── experience-event.schema.json    # Cross-node experience events
  │   └── foundry/                        # OWEN Foundry domain schemas
  │       ├── foundry-source.schema.json
  │       ├── foundry-perspective.schema.json
  │       ├── foundry-claim.schema.json
  │       ├── foundry-hypothesis.schema.json
  │       ├── foundry-evidence-link.schema.json
  │       ├── foundry-decision.schema.json
  │       ├── foundry-experiment.schema.json
  │       └── foundry-initiative.schema.json
  │
  ├── examples/
  │   ├── hypedope/                       # Reference calibration node for HypeDope
  │   └── foundry/                        # Reference workflow for collaborator field email
  │       └── jobber-pricing-reference-workflow.yaml
  │
  ├── src/                                # Kernel TypeScript implementation
  │   ├── core/                           # Core actor, evaluator & validator engines
  │   ├── contracts/                      # Strongly typed schema mirrors & shared contracts
  │   ├── assurance/                      # Assurance assessment kernel
  │   └── foundry/                        # Foundry venture & learning kernel
  │       ├── contracts/                  # Foundry domain contracts
  │       ├── store/                      # Foundry storage implementations
  │       └── services/                   # FoundryEngine & lifecycle orchestrators
  │
  └── tests/                              # Verification test harness
      ├── schemas.test.ts
      ├── authority-evaluator.test.ts
      ├── assurance-assessor.test.ts
      ├── foundry-schemas.test.ts
      ├── foundry-invariants.test.ts
      └── foundry-workflow.test.ts
```

---

## 6. Development & Verification

### Prerequisites
- Node.js 22+
- npm 10+

### Running the Test Suite
```bash
# Type check contracts and source
npm run typecheck

# Run complete test suite (schemas, authority evaluation, assurance assessment)
npm test
```
